#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
#!/usr/bin/python
import sys
import os
from tkinter import *
import tkinter
from tkinter.filedialog import askopenfile 

from tkinter import ttk
from PIL import Image,  ImageTk


# In[12]:


window = tkinter.Tk()
# to rename the title of the window
window.title("Position Report Update")
window.geometry("600x600")
img = ImageTk.PhotoImage(Image.open(r'C:\Users\octo.long\Desktop\python\GUI\shutup.jpg'))

#The Label widget is a standard Tkinter widget used to display a text or image on the screen.
panel = tkinter.Label(window, image = img).pack(side = "bottom", fill = "both", expand = "yes")


# pack is used to show the object in the window
label = tkinter.Label(window, text = "Welcome to hell, where you need to update the position report"
                      ,background="#34A2FE"
                      ,width=600
                      ,height=2).pack()

def create_window():    
    window_result= tkinter.Tk()
    window_result.title("Result")
    label = tkinter.Label(window_result, text= "Hey whatsup bro, i am doing something very interresting."
                          ,background="#34A2FE").pack()
    window_result.geometry("500x200")
    def close_window_result (): 
        window_result.destroy()

    frame_result = Frame(window_result)
    frame_result.pack()
    button_result = Button (frame_result, text = "Good-bye."
                    ,bg="Yellow"
                    ,fg="black"
                    ,command = close_window_result)
    button_result.pack()

    
button1 = tkinter.Button(window,
    text="Click here to start the app!",
    bg="brown",
    fg="black",
    command = create_window
).pack()



def close_window (): 
    window.destroy()

frame = Frame(window)
frame.pack()
button2 = Button (frame, text = "Good-bye."
                ,bg="Yellow"
                ,fg="black"
                ,command = close_window)
button2.pack()

def open_file(): 
    file = askopenfile(mode ='r', filetypes =[('CSV FILE', '*.csv')]) 
    if file is not None: 
        content = file.read() 
        print(content) 

button_upload = tkinter.Button(window,
    text="Upload File",
    bg="white",
    fg="black",
    command = lambda:open_file()
).pack()
        


window.mainloop()


# In[ ]:





# In[ ]:




